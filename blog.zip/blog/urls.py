#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from django.urls import path
from .import views
from .views import *

urlpatterns = [
    path('', Index.as_view(), name = 'index'),  # 首页
    path('about1/', About1.as_view(), name = 'about1'),  # 关于人物
    path('symj/', Symj.as_view(), name = 'symj'), # 思源美景
    path('bly/', Bly.as_view(), name = 'bly'),  # 白鹿原美景
    path('bomb/', Bomb.as_view(), name = 'bomb'),
    path('Character/', Character.as_view(), name = 'Character'),
    path('perspective/', Perspective.as_view(), name = 'perspective'),
    path('rotate/', Rotate.as_view(), name = 'rotate'),
    path('slide/', Slide.as_view(), name = 'slide'),
    path('tin/', Tin.as_view(), name = 'tin'),
    path('team/', Team.as_view(), name= 'team'),

    path('index1/', Index1.as_view(), name='index1'),  # 首页
    path('archive/', Archive.as_view(), name='archive'),  # 归档
    path('link/', Link.as_view(), name='link'),   # 链接
    path('message', Message.as_view(), name='message'),   # 留言
    path('article/<int:pk>/', Articles.as_view(), name='article'),   # 文章列表
    path('get_comment/', GetComment, name='get_comment'),  # 留言信息回推接收
    path('detail/<int:pk>/', Detail.as_view(), name='detail'),   # 文章详情
    path('search/', Search.as_view(), name='search'),     # 全局搜索处理
    path('tag/<int:id>/', Tagcloud.as_view(), name='tag'),   # 标签云

]
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json

from django.http import JsonResponse  # 用于返回json数据
from django.shortcuts import render, get_object_or_404  # 用于页面后台渲染，用于使用报错模式获取对象（如果找不到该对象，则报404错误）
from django.views.generic import View  # 使用Django自带的视图处理不同类型的请求
from django.views.decorators.csrf import csrf_exempt  # 用于标识一个视图可以被跨域访问
from django.db.models import Q  # Q查询——对对象的复杂查询


# 使用继承自View的视图类，可以直接定义get或post的方法
class Index(View):
    """首页显示"""
    def get(self, request):
        # 使用render()，在后端对页面进行渲染
        return render(request, 'index.html')



class Team(View):
    """
    关于人物
    team.html页面
    """
    def get(self, request):
        return render(request, 'team.html')


class About1(View):
    """
    关于人物
    about.html页面
    """
    def get(self, request):
        return render(request, 'about1.html')


class Symj(View):
    """
    思源美景
    symj.html页面
    """
    def get(self, request):
        return render(request, 'symj.html')


class Bly(View):
    """
    白鹿原美景
    bly.html页面
    """
    def get(self, request):
        return render(request, 'bly.html')


class Bomb(View):
    """
    人物Bomb
    bomb.html页面
    """
    def get(self, request):
        return render(request, 'bomb.html')


class Character(View):
    """
    人物Character
    Character.html页面
    """
    def get(self, request):
        return render(request, 'Character.html')


class Perspective(View):
    """
    人物Perspective
    perspective.html页面
    """
    def get(self, request):
        return render(request, 'perspective.html')


class Rotate(View):
    """
    人物Rotate
    rotate.html页面
    """
    def get(self, request):
        return render(request, 'rotate.html')


class Slide(View) :
    """
    人物Slide
    slide.html页面
    """
    def get(self, request) :
        return render(request, 'slide.html')


class Tin(View) :
    """
    人物Tin
    tin.html页面
    """
    def get(self, request) :
        return render(request, 'tin.html')


def page_not_look(request):
    """全局403配置"""
    from django.shortcuts import render_to_response
    response = render_to_response('403.html', {})
    response.status_code = 403
    return response


def page_not_found(request):
    """全局404配置"""
    from django.shortcuts import render_to_response
    response = render_to_response('404.html', {})
    response.status_code = 404
    return response


def page_error(request):
    """全局500配置"""
    from django.shortcuts import render_to_response
    response = render_to_response('500.html', {})
    response.status_code = 500
    return response


import json

from django.http import JsonResponse  # 用于返回json数据
from django.shortcuts import render, get_object_or_404  # 用于页面后台渲染，用于使用报错模式获取对象（如果找不到该对象，则报404错误）
from django.views.generic import View  # 使用Django自带的视图处理不同类型的请求
from django.views.decorators.csrf import csrf_exempt  # 用于标识一个视图可以被跨域访问
from django.db.models import Q  # Q查询——对对象的复杂查询

from .models import Blog, Category, Conment, Tagprofile, User


# 使用继承自View的视图类，可以直接定义get或post的方法
class Index1(View):
    """首页显示"""

    def get(self, request):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        # 首页最新文章列表，按照编辑时间进行排序，取前5篇进行展示
        article_list = Blog.objects.all().order_by('-edit_time')[:5]
        # 首页最热文章列表，按照评论数量进行排序，取前5篇进行展示
        article_rank = Blog.objects.all().order_by('-conment_nums')[:5]

        # 使用render()，在后端对页面进行渲染
        return render(request, 'index1.html', {
            'article_list': article_list,
            'article_rank': article_rank,
            'category_list': category_list,
            'tag_list': tag_list,
            'comment_list': comment_list,
        })


class Articles(View):
    """博客文章列表页面"""

    def get(self, request, pk):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        # 获取指定分类的文件
        if pk:
            category_obj = get_object_or_404(Category, id=pk)
            category = category_obj.name
            article_list = Blog.objects.filter(category_id=pk)
        else:  # pk=0时，获取全部列表
            article_list = Blog.objects.all()
            category = ''
        count = article_list.count()

        return render(request, 'articles.html', {
            'article_list': article_list,
            'category': category,
            'count': count,
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,

        })


class Archive(View):
    """归档，以时间线展示博客文章历程"""

    def get(self, request):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        # 对编辑时间进行排序
        article_list = Blog.objects.all().order_by('-edit_time')

        return render(request, 'archive.html', {
            'article_list': article_list,
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
        })


class Link(View):
    """链接，可以放入多个页面链接，直接编辑link.html页面"""

    def get(self, request):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        return render(request, 'link.html', {
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
        })


class Message(View):
    """留言"""

    def get(self, request):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        return render(request, 'message_board.html', {
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
        })


class Search(View):
    """搜索"""

    def get(self, request):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        key = request.GET.get('key', '')
        if key:
            # 使用Q查询，对标题、博文内容进行全局搜索
            article_list = Blog.objects.filter(Q(title__icontains=key) | Q(content__icontains=key))

        else:
            article_list = ''
        count = article_list.count()
        return render(request, 'search.html', {
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
            'article_list': article_list,
            'count': count,
            'key': key,
        })


@csrf_exempt
def GetComment(request):
    """
    接收畅言的评论回推， post方式回推
    """
    try:
        arg = request.POST
        data = arg.get('data')
        data = json.loads(data)
        title = data.get('title')
        url = data.get('url')
        source_id = data.get('sourceid')
        if source_id not in ['message']:
            article = Blog.objects.get(id=source_id)
            article.commenced()
        comments = data.get('comments')[0]
        content = comments.get('content')
        user = comments.get('user').get('nickname')
        Conment(title=title, source_id=source_id, user=user, url=url, conment=content).save()
        return JsonResponse({"status": "ok"})
    except BaseException as e:
        return JsonResponse({"status": "failed"})


class Detail(View):
    """博客详情页"""

    def get(self, request, pk):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        article = get_object_or_404(Blog, id=pk)

        # 增加阅读数
        article.viewed()

        return render(request, 'detail.html', {
            'article': article,
            'source_id': article.id,
            'tag_list': tag_list,
            'category_list': category_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
        })


class Tagcloud(View):
    """
    标签云
    当点击标签时，显示有此标签的所有文章
    """

    def get(self, request, id):
        # 以下部分可以定义为全局变量
        tag_list = Tagprofile.objects.all()  # 标签云
        category_list = Category.objects.all()  # 分类
        article_rank = Blog.objects.all().order_by('-conment_nums')[:10]  # 热门博客
        comment_list = Conment.objects.all().order_by('-add_time')[:20]  # 最新评论

        tag = get_object_or_404(Tagprofile, id=id).tag_name
        article_list = Blog.objects.filter(tag__tag_name=tag)
        count = article_list.count()
        return render(request, 'tag.html', {
            'tag': tag,
            'article_list': article_list,
            'category_list': category_list,
            'tag_list': tag_list,
            'article_rank': article_rank,
            'comment_list': comment_list,
            'count': count,
        })
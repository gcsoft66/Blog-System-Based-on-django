# _*_ coding:utf-8 _*_
from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = 'blog'
    verbose_name = '文章信息'   # 定义后台管理界面，中文显示应用名称
